<?php
/*
"modelName": "Address",
    "calledMethod": "getAreas",
    "methodProperties": {
    "": ""
    },
    "apiKey": "3c81d19dc6c4375bc278f4c329fb03cb"
*/

/*
$url = "https://api.novaposhta.ua/v2.0/json/?";
$url.= "modelName=Address&";
$url.= "calledMethod=getAreas&";
$url.= "apiKey=3c81d19dc6c4375bc278f4c329fb03cb";

$response = file_get_contents($url);

echo "<pre>" . $url . "</pre>";

echo $response;
*/

require_once ("npGetJs.php");


