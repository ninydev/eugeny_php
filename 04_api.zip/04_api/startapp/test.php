Get:
<?php var_dump($_GET);?>
    <hr>
    Post:
<?php var_dump($_POST);?>