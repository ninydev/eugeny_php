        </main>
    </div>
</div>

<footer>
    Get:
    <?php var_dump($_GET);?>
    <hr>
    Post:
    <?php var_dump($_POST);?>
</footer>
</body>
</html>
<?php
